package com.fpsmeter;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

import com.fpsmeter.overlay.OverlayService;

public class MainActivity extends Activity {

    private static final int REQ_OVERLAY = 101;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        if (!Settings.canDrawOverlays(this)) {
            // BUG FIX: original skipped this — service would crash silently on Android 6+
            Toast.makeText(this,
                "Grant 'Display over other apps' permission, then relaunch",
                Toast.LENGTH_LONG).show();

            Intent i = new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())
            );
            startActivityForResult(i, REQ_OVERLAY);
        } else {
            launch();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_OVERLAY) {
            if (Settings.canDrawOverlays(this)) {
                launch();
            } else {
                Toast.makeText(this, "Permission denied — cannot show overlay", Toast.LENGTH_SHORT).show();
            }
            finish();
        }
    }

    private void launch() {
        startForegroundService(new Intent(this, OverlayService.class));
        Toast.makeText(this, "FPS Meter started", Toast.LENGTH_SHORT).show();
        finish();
    }
}
