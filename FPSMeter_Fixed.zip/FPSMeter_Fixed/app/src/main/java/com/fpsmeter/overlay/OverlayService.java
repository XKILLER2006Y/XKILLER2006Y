package com.fpsmeter.overlay;

import android.app.*;
import android.content.Intent;
import android.graphics.*;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.TextView;

import com.fpsmeter.detect.GameLayerDetector;
import com.fpsmeter.fps.*;
import com.fpsmeter.util.RootShell;

import java.util.List;

public class OverlayService extends Service {

    private static final int    NOTIF_ID      = 1;
    private static final String CHANNEL_ID    = "fpsmeter";
    private static final int    POLL_MS       = 250;

    private WindowManager wm;
    private TextView      text;
    private HandlerThread bgThread;
    private Handler       bgHandler;
    private String        layer;

    private final Runnable loop = new Runnable() {
        @Override public void run() {
            // Auto-detect layer once
            if (layer == null) layer = GameLayerDetector.detect();

            if (layer != null) {
                List<Long>   frames  = SurfaceFlingerReader.read(layer);
                double       fps     = FpsCalculator.fps(frames);
                List<Double> times   = FrameAnalyzer.frameTimes(frames);
                double       low     = FrameAnalyzer.onePercentLow(times);
                boolean      stutter = FrameAnalyzer.stutter(times);

                final String display =
                    "FPS " + String.format("%.0f", fps) +
                    "\n1% " + String.format("%.0f", low) +
                    (stutter ? "\n⚠ STUTTER" : "");

                // Post UI update back to main thread
                text.post(() -> text.setText(display));
            } else {
                text.post(() -> text.setText("Searching…"));
            }

            bgHandler.postDelayed(this, POLL_MS);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();

        // BUG FIX: guard — if overlay permission revoked, don't crash
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }

        createNotificationChannel();
        startForeground(NOTIF_ID, buildNotification());

        RootShell.init();

        wm   = (WindowManager) getSystemService(WINDOW_SERVICE);
        text = new TextView(this);
        text.setTextColor(Color.WHITE);
        text.setBackgroundColor(0x99000000);
        text.setTextSize(14);
        text.setPadding(8, 4, 8, 4);
        text.setTypeface(Typeface.MONOSPACE);

        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );
        p.gravity = Gravity.TOP | Gravity.START;
        p.x = 8; p.y = 8;

        wm.addView(text, p);

        // BUG FIX: dumpsys is blocking I/O — must NOT run on main thread
        bgThread = new HandlerThread("fps-poller");
        bgThread.start();
        bgHandler = new Handler(bgThread.getLooper());
        bgHandler.post(loop);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // BUG FIX: original had no onDestroy — view leaked, thread leaked
        if (bgHandler != null) bgHandler.removeCallbacks(loop);
        if (bgThread  != null) bgThread.quitSafely();
        try { if (wm != null && text != null) wm.removeView(text); }
        catch (Exception ignored) {}
    }

    @Override public IBinder onBind(Intent i) { return null; }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "FPS Overlay", NotificationManager.IMPORTANCE_LOW
            );
            ch.setShowBadge(false);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private Notification buildNotification() {
        return new Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("FPS Meter")
            .setContentText("Monitoring BGMI frame rate")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .build();
    }
}
