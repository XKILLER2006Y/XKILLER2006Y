package com.fpsmeter.fps;

import java.util.*;

public class FpsCalculator {

    public static double fps(List<Long> frames) {
        if (frames == null || frames.size() < 2) return 0;

        // Sort — SurfaceFlinger output isn't always chronological
        List<Long> sorted = new ArrayList<>(frames);
        Collections.sort(sorted);

        long first = sorted.get(0);
        long last  = sorted.get(sorted.size() - 1);

        double seconds = (last - first) / 1e9;
        if (seconds <= 0) return 0;

        return (sorted.size() - 1) / seconds;
    }
}
