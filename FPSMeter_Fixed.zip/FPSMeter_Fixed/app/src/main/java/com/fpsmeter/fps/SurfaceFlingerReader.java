package com.fpsmeter.fps;

import java.util.*;
import com.fpsmeter.util.RootShell;

public class SurfaceFlingerReader {

    // Sentinel value SurfaceFlinger writes for frames not yet presented
    private static final long NOT_PRESENTED = Long.MAX_VALUE; // 9223372036854775807

    public static List<Long> read(String layer) {
        List<Long> frames = new ArrayList<>();
        if (layer == null) return frames;

        String out = RootShell.exec("dumpsys SurfaceFlinger --latency \"" + layer + "\"");
        if (out == null || out.isEmpty()) return frames;

        String[] lines = out.split("\n");

        // Line 0: refresh period (nanoseconds) - skip
        // Lines 1+: desired_present | actual_present | frame_ready  (all nanoseconds)
        for (int i = 1; i < lines.length; i++) {
            String[] cols = lines[i].trim().split("\\s+");
            if (cols.length >= 2) {
                try {
                    long t = Long.parseLong(cols[1]); // actual_present_time
                    // BUG FIX: filter NOT_PRESENTED sentinel and zero (frame was dropped/pending)
                    if (t > 0 && t != NOT_PRESENTED) {
                        frames.add(t);
                    }
                } catch (NumberFormatException ignored) {}
            }
        }
        return frames;
    }
}
