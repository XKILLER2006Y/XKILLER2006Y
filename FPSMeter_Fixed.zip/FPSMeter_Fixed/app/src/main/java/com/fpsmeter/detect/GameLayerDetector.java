package com.fpsmeter.detect;

import com.fpsmeter.util.RootShell;

public class GameLayerDetector {

    // BGMI package - also try KR variant
    private static final String[] TARGETS = {
        "com.pubg.imobile",
        "com.pubg.krmobile"
    };

    public static String detect() {
        String list = RootShell.exec("dumpsys SurfaceFlinger --list");
        if (list == null || list.isEmpty()) return null;

        for (String line : list.split("\n")) {
            String trimmed = line.trim();
            for (String pkg : TARGETS) {
                // BUG FIX: original required "GameActivity" - BGMI never has that in layer name.
                // Only need: SurfaceView + package name.
                if (trimmed.contains(pkg) && trimmed.contains("SurfaceView")) {
                    // Strip the #N instance suffix before passing to --latency
                    int hash = trimmed.indexOf('#');
                    if (hash > 0) trimmed = trimmed.substring(0, hash);
                    return trimmed.trim();
                }
            }
        }
        return null;
    }
}
