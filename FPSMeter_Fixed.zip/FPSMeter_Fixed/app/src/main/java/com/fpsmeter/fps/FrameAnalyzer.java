package com.fpsmeter.fps;

import java.util.*;

public class FrameAnalyzer {

    public static List<Double> frameTimes(List<Long> frames) {
        List<Double> times = new ArrayList<>();
        if (frames == null || frames.size() < 2) return times;

        // Ensure sorted before computing deltas
        List<Long> sorted = new ArrayList<>(frames);
        Collections.sort(sorted);

        for (int i = 1; i < sorted.size(); i++) {
            double dt = (sorted.get(i) - sorted.get(i - 1)) / 1e6; // ns → ms
            if (dt > 0) times.add(dt);
        }
        return times;
    }

    /**
     * 1% Low: FPS of the slowest 1% of frames (highest frame times).
     * BUG FIX: was sorting the caller's list in-place → data corruption.
     */
    public static double onePercentLow(List<Double> times) {
        if (times == null || times.size() < 5) return 0;

        List<Double> copy = new ArrayList<>(times); // defensive copy
        Collections.sort(copy);                     // ascending: slowest at end

        int index = (int) (copy.size() * 0.99);
        double worstMs = copy.get(index);
        if (worstMs <= 0) return 0;

        return 1000.0 / worstMs;
    }

    public static boolean stutter(List<Double> times) {
        if (times == null || times.isEmpty()) return false;

        double avg = 0;
        for (double t : times) avg += t;
        avg /= times.size();

        for (double t : times) {
            if (t > avg * 2.5) return true; // tightened from 2x → 2.5x (less false positives)
        }
        return false;
    }
}
