package com.fpsmeter.util;

import java.io.*;

public class RootShell {

    private static Process    process;
    private static DataOutputStream stdin;
    private static BufferedReader   stdout;

    public static synchronized void init() {
        try {
            process = Runtime.getRuntime().exec("su");
            stdin   = new DataOutputStream(process.getOutputStream());
            stdout  = new BufferedReader(new InputStreamReader(process.getInputStream()));
        } catch (Exception e) {
            process = null;
            stdin   = null;
            stdout  = null;
        }
    }

    /** Re-init if the su process has died between calls. */
    private static synchronized boolean ensureAlive() {
        if (stdin == null || stdout == null) {
            init();
        } else {
            try {
                process.exitValue(); // throws if still running
                init();              // process exited → re-spawn
            } catch (IllegalThreadStateException ignored) {
                // still alive — good
            }
        }
        return stdin != null && stdout != null;
    }

    public static synchronized String exec(String cmd) {
        if (!ensureAlive()) return "";

        StringBuilder out = new StringBuilder();
        try {
            stdin.writeBytes(cmd + "\n");
            stdin.writeBytes("echo __END__\n");
            stdin.flush();

            String line;
            while ((line = stdout.readLine()) != null) {
                if (line.equals("__END__")) break;
                out.append(line).append("\n");
            }
        } catch (Exception e) {
            // Shell died mid-read — force reconnect next call
            process = null; stdin = null; stdout = null;
        }
        return out.toString();
    }
}
